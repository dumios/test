import UIKit

/* ПЕРВОЕ ЗАДАНИЕ
 Решите квадратное уравнение ax^2 - bx + c = 0

let a = 1
let b = 4
let c = 3
var x1 = 0
var x2 = 0

var D = (b*b)-(4*a*c)

if D == 0 {
    x1 = (-b + Int(sqrt(Double(D)))/2*a)
    print ("х1 = \(x1)")
}
else if D < 0 {
    print("КОРНЕЙ НЕТ")
}
else {
    x1 = (-b + Int(sqrt(Double(D)))/2*a)

    x2 = (-b - Int(sqrt(Double(D)))/2*a)
    print ("х1 = \(x1), a х2 = \(x2)")
}
*/





/* ВТОРОЕ ЗАДАНИЕ
 Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника.
 

let a = 2
let b = 4
var c = 0
var S = 0
var P = 0

c = Int(sqrt(Double(a*a) + Double(b*b)))
S = a*b/2
P = a + b + c
print("c = \(c), S = \(S), a P = \(P)")
 */

