import UIKit

// Решите квадратное уравнение ax^2 - bx + c = 0

let a = 1
let b = 4
let c = 3
var x1 = 0
var x2 = 0

var D = (b*b)-(4*a*c)

if D == 0 {
    x1 = (-b + Int(sqrt(Double(D)))/2*a)
}
else if D < 0 {
    print("КОРНЕЙ НЕТ")
}
else {
    x1 = (-b + Int(sqrt(Double(D)))/2*a)

    x2 = (-b - Int(sqrt(Double(D)))/2*a)
    print ("х1 = \(x1), a х2 = \(x2)")
}


